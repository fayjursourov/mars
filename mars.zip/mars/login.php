<?php
echo constant("GREETING");